#!/bin/bash

# Define color codes
WHITE="\033[1;37m"
GREEN="\e[1;92m"
SKY_BLUE="\e[38;2;0;191;255m"
RED="\033[38;2;255;13;13m"
YELLOW="\033[1;33m"

# For System Header Logo
banner(){
  clear
  printf "${GREEN}  ┏┓┓    ┓     ┏┓"
  printf "\n${GREEN}  ┗┓┣┓┏┓┏┫┏┓┓┏┏┃.┏┓┏┏┓╋"
  printf "\n${GREEN}  ┗┛┛┗┗┻┗┻┗┛┗┻┛┗┛┛┗┫┣┛┗"
  printf "\n${GREEN}                   ┛┛"
  printf "\n${GREEN}▐=======================▌"
  printf "\n${GREEN}    Coded by ${SKY_BLUE}MR_JLTC${WHITE}"
  printf "\n ${RED}      v3.0-BETA\n\n\e${WHITE}"
  printf "${YELLOW}[${RED}G${YELLOW}]> ${WHITE}https://github.com/MR-JLTC${WHITE}\n"
  printf "${YELLOW}[⨹]>${GREEN} WELCOME MY FELLOW CIPHEROLOGISTS\n\n"
}

# Executes the system
execSys(){
  clear
  java -jar "dist/ShadowCrypt.jar"
}

OpenJdkInstaller(){
    sleep 1
    echo -e "${WHITE}[◈]> ${SKY_BLUE}Starting installation of OpenJDK17...${WHITE}"
    pkg update && upgrade -y
    pkg install -y openjdk-17
}

reqAnalyzer(){
   echo -e "${WHITE}[◈]> ${SKY_BLUE}Preparing the requirement${WHITE}"
   if dpkg -s openjdk-17 &> /dev/null; then
       sleep 1
       echo -e "${NC}[◈]> ${SKY_BLUE}OpenJDK17 is ready${WHITE}"
       sleep 1
       echo -e "${NC}[◈]> ${SKY_BLUE}Powering up the system...${WHITE}"
       sleep 1.7
       execSys
   else
       sleep 1
       echo -e "${NC}[◈]> ${RED}OpenJDK17 is missing"
       OpenJdkInstaller
       if dpkg -s openjdk-17 &> /dev/null; then
           sleep 1
           echo -e "${NC}[◈]> ${SKY_BLUE}Installation successful${WHITE}"
           sleep 1
           echo -e "${NC}[◈]> ${SKY_BLUE}Powering up the system...${WHITE}"
           sleep 1.7
          execSys
      else
          echo -e "${NC}[◈]> ${RED}Installation failed${WHITE}"
          echo -e "${NC}[◈]> ${SKY_BLUE}Initiating reinstallation process..${WHITE}"
          sleep 1
          OpenJdkInstaller
       fi
   fi
}

banner
reqAnalyzer